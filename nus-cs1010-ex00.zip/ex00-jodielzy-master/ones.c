/**
 * CS1010 Semester 1 AY22/23
 * Exercise 0: Ones
 *
 * Read in a positive integer larger than 10 and print the 
 * last digit followed by the other digits.
 *
 * @file: ones.c
 * @author: Jodie (Group D03)
 */

#include "cs1010.h"

int main()
{
 long x = cs1010_read_long();
 cs1010_println_long( x % 10 );
 cs1010_println_long(x / 10);
 return 0;
}

