/**
 * CS1010 Semester 1 AY22/23
 * Exercise 0: BMI
 *
 * Read in two real numbers representing height and weight of 
 * a person, print the BMI of the person.
 *
 * @file: bmi.c
 * @author: Jodie (Group D03)
 */

#include "cs1010.h"

double compute_bmi(double weight_kg, double height_m)
{
  double squared_h = height_m * height_m;
  double bmi = weight_kg / squared_h;
  return bmi;
}
 
int main()
{
  double height_cm = cs1010_read_double();
  double weight_kg = cs1010_read_double();
  double height_m = height_cm / 100;
  double bmi = compute_bmi(weight_kg, height_m);
  cs1010_println_double(bmi);
  return 0;
}

 
