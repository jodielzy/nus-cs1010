/**
 * CS1010 Semester 1 AY22/23
 * Assignment 1: Cuboid
 *
 * Read in three positive integer corresponding to the width,
 * length, and height of a cuboid from the standard input, and
 * print the total surface area and the length of its diagonal
 * to the standard output.
 *
 * @file: cuboid.c
 * @author: Jodie (Group D03)
 */

#include "cs1010.h"
#include <math.h>

double hypotenuse_of(double side1, double side2)
{
  double square = (side1 * side1) + (side2 * side2);
  return sqrt(square);
}

long area_of_rectangle(long length, long width)
{
  long area = length * width;
  return area;
}

int main() 
{
  long w = cs1010_read_long();
  long l = cs1010_read_long();
  long h = cs1010_read_long();
  long front_back = area_of_rectangle(w, h);
  long left_right = area_of_rectangle(l, h);
  long up_down = area_of_rectangle(w, l);
  cs1010_println_long((2 * front_back) + (2 * left_right) + (2 * up_down));
  double base = hypotenuse_of((double) w, (double) l);
  cs1010_println_double(hypotenuse_of(base, (double) h));
  return 0;
}
  
