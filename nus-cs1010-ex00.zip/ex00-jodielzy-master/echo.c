/**
 * CS1010 Semester 1 AY22/23
 * Exercise 0: Echo
 *
 * Read in an integer and print it on the screen.
 *
 * @file: echo.c
 * @author: Jodie (Group D03)
 */

#include "cs1010.h"

int main()
{
   long x = cs1010_read_long();
   cs1010_println_long(x);
   return 0;
}
